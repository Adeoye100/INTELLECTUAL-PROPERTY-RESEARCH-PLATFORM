import React, { Suspense } from 'react';
import { BrowserRouter, Routes, Route } from 'react-router-dom';

const LandingPage = React.lazy(() =>
import('./pages/LandingPage').then((m) => ({ default: m.LandingPage }))
);
const SignUpPlaceholder = React.lazy(() =>
import('./pages/SignUpPlaceholder').then((m) => ({ default: m.SignUpPlaceholder }))
);

function RouteLoadingFallback() {
  return (
    <div className="min-h-screen w-full bg-gradient-to-b from-forge-navy to-forge-teal" />);

}

// The public landing page ("/") is lazy-loaded so its Three.js / React Three
// Fiber scene never bloats the authenticated app's bundle — it's a separate,
// isolated marketing surface that sits in front of the app shell.
export function App() {
  return (
    <BrowserRouter>
      <Suspense fallback={<RouteLoadingFallback />}>
        <Routes>
          <Route path="/" element={<LandingPage />} />
          <Route path="/signup" element={<SignUpPlaceholder />} />
        </Routes>
      </Suspense>
    </BrowserRouter>);

}