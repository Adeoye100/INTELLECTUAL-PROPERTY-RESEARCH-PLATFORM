export default {content: [
  './index.html',
  './src/**/*.{js,ts,jsx,tsx}'
],
  theme: {
    extend: {
      colors: {
        'forge-navy': '#0A1428',
        'forge-teal': '#146575',
        'forge-silver': {
          50: '#F7F8FA',
          100: '#EDEFF3',
          200: '#D9DEE5',
          300: '#C2C9D2',
          400: '#A6AFBC',
          500: '#8B95A3',
          600: '#6E7787',
          700: '#545C6B',
          800: '#3A4150',
          900: '#232833'
        },
        'forge-text-onDark': '#FFFFFF',
        'forge-subtext-onDark': '#8FAEC0'
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif'],
        mono: ['IBM Plex Mono', 'ui-monospace', 'monospace']
      },
      animation: {
        'bounce-slow': 'bounce-slow 2.4s ease-in-out infinite'
      },
      keyframes: {
        'bounce-slow': {
          '0%, 100%': { transform: 'translateY(0)' },
          '50%': { transform: 'translateY(8px)' }
        }
      }
    }
  },
  plugins: []
};
