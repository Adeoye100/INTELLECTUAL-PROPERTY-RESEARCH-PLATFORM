import React from 'react';
import { Link } from 'react-router-dom';
import { ArrowLeftIcon } from 'lucide-react';
import { ShieldStatic } from '../components/landing/ShieldStatic';

// Placeholder destination for the landing page's CTA. The authenticated app
// shell and its real sign-up / login screen (per the frontend build prompt)
// live outside this marketing route — this keeps the CTA a real, working
// link into that flow rather than a dead link until it's wired up.
export function SignUpPlaceholder() {
  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center bg-gradient-to-b from-forge-navy to-forge-teal text-forge-text-onDark px-6 py-16">
      <ShieldStatic size={120} animated={false} />
      <h1 className="mt-8 text-2xl md:text-3xl font-semibold text-forge-text-onDark text-center">
        Sign up / sign in
      </h1>
      <p className="mt-3 max-w-md text-center text-forge-subtext-onDark">
        The authenticated app and its sign-up flow live here. Connect this route to
        the account creation and login screens once that shell is built out.
      </p>
      <Link
        to="/"
        className="mt-10 inline-flex items-center gap-2 text-sm text-forge-silver-300 hover:text-forge-text-onDark transition-colors">
        
        <ArrowLeftIcon className="w-4 h-4" aria-hidden="true" />
        Back to home
      </Link>
    </div>);

}